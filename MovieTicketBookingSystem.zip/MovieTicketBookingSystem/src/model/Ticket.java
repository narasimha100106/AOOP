package model;

public interface Ticket {
	 String getType();
	    double getPrice();
}
