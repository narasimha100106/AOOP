package model;

public interface TicketFactory {
	Ticket createTicket();
}
